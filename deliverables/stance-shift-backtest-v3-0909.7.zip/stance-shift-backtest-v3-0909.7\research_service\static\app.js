const $ = (id) => document.getElementById(id);
const escape = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const percentage = value => value == null ? '—' : `${(value * 100).toFixed(1)}%`;
const number = value => value == null ? '—' : Number(value).toFixed(3);
const statuses = {queued:'等待執行',running:'執行中',paused:'已暫停',complete:'已完成',cancelled:'已取消'};
let selectedJob = null, selectedProtocol = null, busy = false, datasetRows = [], parallelWorkers = 1, currentProtocolVersion = '', terminalEvents = [];
let submitting = false, scoring = false;
let hasActiveJobs = false, pollTimer = null, liveSocket = null, finbertReady = false, pollFailures = 0;
const ACTIVE_POLL_MS = 3000, IDLE_POLL_MS = 30000, MAX_POLL_MS = 60000;
function notify(message, error = false) { $('notice').hidden = false; $('notice').className = error ? 'error' : ''; $('notice').textContent = message; }
async function api(path, body, method) {
  const response = await fetch(path, {method: method || (body === undefined ? 'GET' : 'POST'), headers: body === undefined ? {} : {'Content-Type':'application/json'}, body: body === undefined ? undefined : JSON.stringify(body)});
  const data = await response.json();
  if (!response.ok) {
    if (response.status === 401) { $('login').hidden = false; $('workspace').hidden = true; }
    throw new Error(typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail || data));
  }
  return data;
}
async function task(button, fn) { if (button) button.disabled = true; try { await fn(); } catch(error) { notify(error.message, true); } finally { if(button) button.disabled = false; syncExperimentGuard(); } }
function options(items) { return items.map(v => `<option value="${escape(v)}">${escape(v)}</option>`).join(''); }
function modelOptions(items, details) {
  const byId=new Map((details||[]).map(item=>[item.id,item]));
  return items.map(value=>{const detail=byId.get(value), size=detail?.parameter_size, count=Number.parseFloat(size);
    const suffix=size?` · ${size}${Number.isFinite(count)&&count<14?' · 僅冒煙':''}`:'';
    return `<option value="${escape(value)}">${escape(value+suffix)}</option>`;}).join('');
}
function formatStamp(value) { try { return new Intl.DateTimeFormat('zh-TW',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(value)); } catch { return value || '—'; } }
function terminalStamp(value=new Date()) { try { return new Intl.DateTimeFormat('zh-TW',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(value); } catch { return '--:--:--'; } }
function renderAgentTerminal() {
  const output=$('agent-terminal-output'); if(!output)return;
  output.innerHTML=terminalEvents.map(item=>`<div class="terminal-line ${escape(item.tone)}"><time>${escape(item.at)}</time><b>[${escape(item.agent)}]</b><span>${escape(item.message)}</span></div>`).join('')+'<div class="terminal-cursor" aria-hidden="true"><span>›</span><i></i></div>';
  output.scrollTop=output.scrollHeight;
}
function resetAgentTerminal() { terminalEvents=[]; renderAgentTerminal(); }
function terminalLine(agent,message,tone='') { terminalEvents.push({at:terminalStamp(),agent,message,tone}); if(terminalEvents.length>80)terminalEvents.shift(); renderAgentTerminal(); }
function datasetCut(d) { return d.requested_analysis_date || (d.used_analysis_dates || []).slice(-1)[0] || null; }
function datasetLabel(d) { const cut=datasetCut(d); return `${d.ticker} · ${d.kind === 'synthetic' ? '合成測試' : '歷史資料'} v${d.version} · ${cut ? `研究日 ${cut}` : '研究日未記錄'} · 未來行情終點 ${d.price_end}（只供回測）`; }
const collectorInfo={technical:['技術面 Agent','Yahoo 還原 OHLC'],fundamental:['基本面 Agent','SEC XBRL'],sentiment:['情緒面 Agent','Alpha Vantage／FNSPID'],macro:['總經面 Agent','ALFRED vintage']};
const collectorStatus={idle:'尚未啟動',running:'收集中',complete:'完成',needs_input:'待補資料',needs_configuration:'未設定來源',missing:'缺資料',error:'失敗'};
function missingPolicyLabel(protocol={}) { return (protocol.missing_data_policy||'force_no_trade')==='allow_decision'?'缺資料對照 · 保留模型決策':'保守門檻 · 強制 NoTrade'; }
function protocolLabel(protocol={}) { const version=protocol.version||'未記錄'; return `協議 ${version}${currentProtocolVersion&&version!==currentProtocolVersion?' · 舊版結果':''}`; }
function renderCollectionAgents(dataset=null, phase='idle') {
  const counts=dataset?.coverage?.domains||{}, saved=dataset?._collection||{};
  let complete=0, gaps=0;
  for(const [domain,[title,source]] of Object.entries(collectorInfo)){
    let status=phase;
    let message=phase==='running'?'正在並行蒐集與驗證…':source;
    if(dataset){
      const count=counts[domain]||0, meta=saved[domain]||{};
      status=(domain==='technical'?count>=61:count>0)?'complete':'missing';
      message=status==='complete'?`分析日前 ${count} 筆可用資料`:'分析日前資料不足';
    }
    if(status==='complete')complete++; else if(dataset)gaps++;
    const card=$(`collector-${domain}`); card.className=`agent-card ${status}`;
    card.innerHTML=`<b>${escape(title)}</b><small>${escape(source)}</small><span>${escape(collectorStatus[status]||status)}</span><p>${escape(message)}</p>`;
  }
  const readiness=$('data-readiness');
  if(phase==='running') readiness.textContent='四個資料 Agent 已啟動；技術、基本面與總經來源正在並行處理，情緒 Agent 同時檢查可用摘要。';
  else if(!dataset) readiness.textContent='選擇股票與研究分析日後，讓四個 Agent 開始蒐集與驗證資料。';
  else if(gaps===0) readiness.textContent='四域資料驗證完成，可以啟動 A/B/C/D 四組實驗。';
  else readiness.textContent=`資料結構與行情已驗證；${complete}/4 個領域就緒、${gaps} 個領域有缺口。可直接作為缺資料對照，系統會保留缺口標記並依你選的策略處理決策。`;
}
function renderDatasetDetail(alignDate = false) {
  const d=datasetRows.find(row=>row.id===$('dataset').value), detail=$('dataset-detail');
  if(!d){detail.hidden=true;detail.innerHTML='';$('analysis-date').disabled=false;$('score-finbert-button').disabled=true;$('analysis-date-help').textContent='分析日只使用 2021–2025 的季末切點；資料集的行情終點只供分析日後回測。';return;}
  const cut=datasetCut(d), uses=(d.used_analysis_dates||[]).join('、') || '尚未建立實驗';
  detail.hidden=false;
  const quality=d.coverage?.sentiment_quality, qualityText=quality?`新聞目標相關率 ${percentage(quality.ticker_mention_rate)} · ${quality.passes_quality_gate?'通過品質檢查':'未通過品質檢查'}${quality.median_relevance==null?'':` · 中位相關性 ${number(quality.median_relevance)}`}`:'新聞相關性尚未計算';
  detail.innerHTML=`<span class="version">v${d.version}</span><strong>${escape(d.ticker)} · ${d.kind === 'synthetic' ? '合成測試' : '歷史資料'}</strong><br>研究前行情起點 ${escape(d.price_start)} · ${d.price_count} 個交易日 · ${d.evidence_count} 筆證據<br><b>${cut ? `研究分析日：${escape(cut)}` : '研究分析日：舊資料集未記錄'}</b> · 已用切點 ${escape(uses)}<br><b>未來行情終點：${escape(d.price_end)}（只供 30／60／90 日回測，不能選為分析日）</b><br><small>${escape(qualityText)}</small><br>建立 ${escape(formatStamp(d.created_at))} · ${escape(d.source)}<br><code title="完整資料集 ID">ID ${escape(d.id)}</code>`;
  if(alignDate && cut && [...$('analysis-date').options].some(option=>option.value===cut)) $('analysis-date').value=cut;
  $('analysis-date').disabled=Boolean(cut && d.kind==='historical');
  $('score-finbert-button').disabled=scoring || !finbertReady || !(d.evidence_by_domain?.sentiment > 0);
  $('analysis-date-help').textContent=cut
    ? `這筆資料集的研究分析日是 ${cut}；${d.price_end} 是未來行情終點，只拿來計算分析日後 30／60／90 個交易日的回測。`
    : `這筆舊版或匯入資料未記錄研究分析日；請選計劃書的季末切點。${d.price_end} 是未來行情終點，不能當分析日。`;
}
function syncExperimentGuard() {
  const d=datasetRows.find(row=>row.id===$('dataset').value), cut=d&&datasetCut(d);
  const ready=Boolean(d) && (d.kind!=='historical' || cut===$('analysis-date').value), guard=$('experiment-guard'), button=$('run-button');
  button.disabled=!ready || submitting;
  guard.classList.toggle('ready',ready);
  const quality=d?.coverage?.sentiment_quality;
  guard.textContent=ready?(quality && !quality.passes_quality_gate && !$('allow-low-quality-sentiment').checked
    ? `新聞目標相關率僅 ${percentage(quality.ticker_mention_rate)}；啟動前需重新採集，或明確勾選資料品質敏感性覆寫。`
    : '資料集與研究分析日一致；模型、新聞品質與缺口策略會一起鎖定於新實驗。')
    :d?'資料集與研究分析日不一致，不能啟動實驗。':'尚未選擇資料集，因此不能啟動實驗。';
}
async function refreshReadiness() {
  const r=await api('/api/readiness'), done=r.complete_cases, total=r.target_cases;
  const covered=r.tickers.filter(row=>row.complete>0).map(row=>`${row.ticker} ${row.complete}/${r.dates.length}`).join('、') || '尚無完整案例';
  $('study-readiness').innerHTML=`<strong>四域完整 ${done}/${total}</strong> · 60 日行情也齊全 ${r.backtest_ready_cases} · 部分 ${r.partial_cases} · 尚缺 ${r.missing_cases}<br><small>${escape(covered)}。${escape(r.note)}</small>`;
}
async function refreshDatasets() {
  const data = await api('/api/datasets'), previous = $('dataset').value; datasetRows=data;
  $('dataset').innerHTML = '<option value="">請選擇資料集</option>' + data.map(d => `<option value="${escape(d.id)}">${escape(datasetLabel(d))}</option>`).join('');
  if (data.some(d => d.id === previous)) $('dataset').value = previous;
  $('datasets').innerHTML = data.slice(0,5).map(d => `<div><span class="version">v${d.version}</span><strong>${escape(d.ticker)} · ${d.kind === 'synthetic' ? '合成測試' : '歷史資料'}</strong><br>研究分析日 ${escape(datasetCut(d)||'未記錄')}<br>未來行情終點 ${escape(d.price_end)}（只供回測）<br>${d.price_count} 個交易日 · ${d.evidence_count} 筆證據 · 建立 ${escape(formatStamp(d.created_at))}<br><code title="完整資料集 ID">ID ${escape(d.id)}</code><br>${escape(d.source)}</div>`).join('');
  renderDatasetDetail(true);
  renderCollectionAgents(data.find(d=>d.id===$('dataset').value)||null);
  const selected=data.find(d=>d.id===$('dataset').value);
  $('score-finbert-button').disabled=scoring || !finbertReady || !(selected?.evidence_by_domain?.sentiment > 0);
  syncExperimentGuard();
}
async function refreshJobs() {
  const dashboard = await api('/api/dashboard' + (selectedJob ? `?selected=${encodeURIComponent(selectedJob)}` : ''));
  const jobs = dashboard.jobs;
  hasActiveJobs=jobs.some(job=>job.status==='queued'||job.status==='running');
  $('jobs').className = jobs.length ? '' : 'empty';
  $('jobs').innerHTML = jobs.length ? jobs.map(j => `<div class="job"><div><strong>${escape(j.config.ticker)} · ${escape(j.config.analysis_date)}</strong> <span class="status ${escape(j.status)}">${escape(statuses[j.status])}</span><small>${escape(j.config.protocol.model)} · ${j.steps}/${15 + j.config.protocol.voting_samples} 模型輸出${j.wants_run === 0 && j.status === 'running' ? ' · 將在本波次後暫停' : ''}</small><small>${escape(protocolLabel(j.config.protocol))} · ${escape(missingPolicyLabel(j.config.protocol))} · ${escape(j.config.protocol.study)} · ${j.id.slice(0,8)}</small></div><button class="quiet" data-open="${escape(j.id)}">檢視</button></div>`).join('') : '尚無實驗。先準備資料，再建立第一筆研究。';
  if(dashboard.selected) await showJob(selectedJob,dashboard.selected);
  schedulePoll();
}
function schedulePoll() {
  if(pollTimer)clearTimeout(pollTimer);
  pollTimer=null;
  if($('workspace').hidden || document.hidden)return;
  const baseDelay=hasActiveJobs?ACTIVE_POLL_MS:IDLE_POLL_MS;
  const delay=Math.min(MAX_POLL_MS,baseDelay*(2**Math.min(pollFailures,2)));
  pollTimer=setTimeout(async()=>{
    if(document.hidden || $('workspace').hidden)return;
    if(busy){schedulePoll();return;}
    busy=true;
    try{await refreshJobs();pollFailures=0;}
    catch(error){pollFailures=Math.min(pollFailures+1,2);notify(`無法更新狀態：${error.message}`,true);}
    finally{busy=false;schedulePoll();}
  },delay);
}
function researchAgentPanel(s, jobStatus) {
  const labels={technical:'技術面',fundamental:'基本面',sentiment:'情緒面',macro:'總經面'};
  const cards=Object.entries(labels).map(([domain,label])=>{
    const item=(s.research||{})[domain];
    const status=item?.status==='complete'?'complete':item?.status==='degraded'?'degraded':item?.status==='missing'?'missing':s.inputs&&jobStatus==='running'?'running':'idle';
    const state={complete:'分析完成',degraded:'來源摘錄完成',missing:'資料缺口',running:'分析中',idle:'等待資料'}[status];
    return `<article class="agent-card ${status}"><b>${label}研究 Agent</b><small>${escape(domain)}</small><span>${state}</span><p>${escape(item?.summary||'等待 Coordinator 分派同一資料快照')}</p></article>`;
  }).join('');
  return `<section class="execution-block"><div class="subheading"><h3>四個研究 Agent</h3><small>同一資料快照 · ${parallelWorkers} workers</small></div><div class="agent-grid">${cards}</div></section>`;
}
function traceMessage(node='') {
  if(node==='coordinator')return 'Coordinator 鎖定資料快照、分析日與研究協議';
  if(node.startsWith('parallel_research_agents'))return '派發 technical／fundamental／sentiment／macro 四域研究 Agent';
  if(node==='neutral_report_locked')return '四域摘要合併完成，中立研究報告已鎖定';
  if(node.startsWith('parallel_decision_wave'))return `決策波次：${node.slice(node.indexOf('[')+1,-1)}`;
  if(node==='gatekeeper_decisions_locked')return 'Gatekeeper 已核對引用、資料覆蓋與風險門檻';
  if(node==='backtest_and_memory_write')return '回測案例與成熟記憶已持久化';
  return node.replaceAll('_',' ');
}
function runAgentTerminal(job,s) {
  const lines=(s.trace||[]).map(item=>`<div class="terminal-line ok"><time>${escape(terminalStamp(new Date(item.at)))}</time><b>[TRACE]</b><span>${escape(traceMessage(item.node))}</span></div>`).join('');
  const waiting=!['complete','cancelled','paused'].includes(job.status)?'<div class="terminal-line active"><time>NOW</time><b>[WORKER]</b><span>等待下一個持久化檢查點…</span></div>':'';
  return `<section class="execution-block"><div class="subheading"><h3>研究 Agent 終端</h3><small>真實持久化事件 · 執行時每 3 秒、閒置每 30 秒更新；背景分頁暫停更新</small></div><div class="terminal-screen run-terminal"><div class="terminal-line command"><time>CASE</time><b>[SESSION]</b><span>${escape(job.id.slice(0,8))} · ${escape(job.config.protocol.model)} · ${escape(job.config.protocol.version)}</span></div>${lines||'<div class="terminal-line"><time>--:--:--</time><b>[QUEUE]</b><span>等待 Coordinator 領取工作…</span></div>'}${waiting}</div></section>`;
}
function groupPhase(group,count,total) {
  if(count>=total)return '已完成';
  if(group==='A')return '單次決策';
  if(group==='B')return `獨立投票 ${count}/${total}`;
  if(count<2)return '第 1 輪'; if(count<4)return '第 2 輪'; if(count<6)return '第 3 輪'; return '裁決中';
}
function groupProgressPanel(s, protocol, jobStatus) {
  const totals={A:1,B:protocol.voting_samples,C:7,D:7};
  const labels={A:'單次判斷',B:'獨立投票',C:'固定立場',D:'立場交換'};
  const localOllama=String(protocol.model||'').startsWith('ollama/');
  const executionNote=localOllama
    ? '本機 Ollama 決策依序排程，避免模型佇列互相卡住'
    : `${parallelWorkers} workers · 依輪次相依關係並行`;
  const cards=Object.keys(labels).map(group=>{
    const count=(s.records||[]).filter(record=>record.group===group).length, total=totals[group];
    const status=count>=total?'complete':s.report&&jobStatus==='running'?'running':jobStatus==='paused'&&count?'paused':'idle';
    const decision=s.decisions?.[group];
    return `<article class="group-card ${status}"><b>${group} · ${labels[group]}</b><span>${groupPhase(group,count,total)}</span><progress max="${total}" value="${count}" aria-label="${group} 組進度"></progress><small>${count}/${total} 次模型輸出${decision?` · ${escape(decision.action)}`:''}</small></article>`;
  }).join('');
  return `<section class="execution-block"><div class="subheading"><h3>A/B/C/D 實驗執行</h3><small>${escape(executionNote)} · ${escape(missingPolicyLabel(protocol))} · 同輪不互看</small></div><div class="group-grid">${cards}</div></section>`;
}
function backtestComparison(s) {
  if(!s.cases?.length)return '<p class="hint">四組決策鎖定後，系統會自動產生 30／60／90 交易日回測。</p>';
  const rows=s.cases.filter(row=>row.cost_model==='corwin_schultz'&&(row.decision_layer||'gated')==='candidate');
  const cell=(group,horizon)=>{const row=rows.find(item=>item.group===group&&item.horizon===horizon);return !row||row.status==='pending'?'<span class="pending">待成熟</span>':row.status!=='complete'?escape(row.status):percentage(row.net_return);};
  const benchmark=rows.find(row=>row.horizon===60&&row.status==='complete');
  return `<section class="execution-block"><div class="subheading"><h3>四組結果與回測比較</h3><small>Corwin–Schultz 成本後淨報酬</small></div><div class="table-wrap"><table><thead><tr><th>組別</th><th>最終決策</th><th>30 日</th><th>60 日（主要）</th><th>90 日</th></tr></thead><tbody>${'ABCD'.split('').map(group=>`<tr><td><b>${group}</b></td><td>${escape(s.decisions?.[group]?.action||'—')}</td><td>${cell(group,30)}</td><td>${cell(group,60)}</td><td>${cell(group,90)}</td></tr>`).join('')}</tbody></table></div><p class="hint">同期間 60 日 Buy-and-Hold：${benchmark?percentage(benchmark.benchmark_return):'待成熟'}。完整逐日報酬、零成本版本與統計檢定可由 ZIP 下載。</p></section>`;
}
async function showJob(id, loadedJob=null) {
  selectedJob = id;
  const job = loadedJob || await api(`/api/jobs/${id}`), s = job.state, total = 15 + job.config.protocol.voting_samples;
  selectedProtocol = job.config.protocol_hash;
  const output = $('run-detail'); output.hidden = false;
  const isFinal = ['complete','cancelled'].includes(job.status);
  const trace = s.trace.at(-1)?.node || '等待 Coordinator';
  const oldProtocol = currentProtocolVersion && job.config.protocol.version !== currentProtocolVersion;
  const protocolNotice = oldProtocol
    ? `這是協議 ${job.config.protocol.version || '未記錄'} 的既有結果；決策規則修正只會套用於 ${currentProtocolVersion} 新建立的實驗。`
    : `${protocolLabel(job.config.protocol)} · 使用目前的 Buy／Hold／Sell 候選決策規則。`;
  output.innerHTML = `<div class="section-label">CASE / ${escape(id.slice(0,8))}</div><h2>${escape(job.config.ticker)} · ${escape(job.config.analysis_date)} <span class="status ${escape(job.status)}">${escape(statuses[job.status])}</span></h2><p class="${oldProtocol?'protocol-warning':'hint'}">${escape(protocolNotice)}</p><p class="hint">目前：${escape(trace)} · ${s.records.length}/${total} 決策輸出 · ${s.attempts.length} 次持久化波次</p><progress class="progress" max="${total}" value="${s.records.length}" aria-label="決策推論進度"></progress>${job.error ? `<p class="error-text">${escape(job.error)}</p>` : ''}<div class="actions">${oldProtocol ? `<button class="quiet" data-clone="${escape(id)}">複製至新版重新執行</button>` : ''}${!isFinal && !oldProtocol ? `<button class="quiet" data-control="${job.wants_run ? 'pause' : 'resume'}">${job.wants_run ? '暫停' : '繼續執行'}</button><button class="quiet" data-control="cancel">取消實驗</button>` : ''}<a href="/api/jobs/${id}/export">下載研究產物 ZIP</a>${job.status === 'complete' ? '<button data-statistics="true">檢視同協議統計</button>' : ''}</div>${runAgentTerminal(job,s)}${researchAgentPanel(s,job.status)}${groupProgressPanel(s,job.config.protocol,job.status)}${s.decisions ? `<div class="decisions">${Object.entries(s.decisions).map(([g,d]) => `<div><small>${g} 組 · 信心 ${percentage(d.confidence)} · 預測 ${number(d.expected_return_pct)}%</small><strong>${escape(d.action)}</strong><small>模型：${escape(d.model_action||d.candidate_action)} · 推導：${escape(d.derived_action||d.candidate_action)} · 候選：${escape(d.candidate_action)}<br>中性帶 ±${number(d.hold_band_pct)}% · 資料覆蓋 ${percentage(d.gate.domain_coverage)}<br>${d.gate.missing_data_control?'缺資料對照：未覆寫模型決策<br>':''}${escape(d.gate.reasons.join(' / ') || '通過門檻')}</small></div>`).join('')}</div>` : '<p class="hint">四組完成後由 Gatekeeper 同步鎖定決策。</p>'}${backtestComparison(s)}<details><summary>中立研究報告與來源</summary><pre>${escape(JSON.stringify(s.report || s.research, null, 2))}</pre></details><details><summary>逐步論證與三輪立場交換（${s.records.length}）</summary>${s.records.map(r => `<article class="trace"><strong>${escape(r.group)} · ${escape(r.key)} · ${escape(r.stance)}</strong><p>${escape(r.output.rationale)}</p><small>引用：${escape(r.output.evidence_ids.join(', '))}<br>提示雜湊：${escape(r.audit.prompt_hash)}</small></article>`).join('')}</details><details><summary>回測、門檻與流程紀錄</summary><pre>${escape(JSON.stringify({decisions:s.decisions,cases:s.cases,compute_usage:s.compute_usage,completeness_diagnostic:s.completeness_diagnostic,trace:s.trace},null,2))}</pre></details>`;
}
async function showStatistics() {
  const [report,pilot,band] = await Promise.all([api(`/api/studies/${selectedProtocol}`),api(`/api/studies/${selectedProtocol}/pilot`),api(`/api/studies/${selectedProtocol}/hold-band`)]), element = $('statistics'); element.hidden = false;
  const primary = report.summary.filter(r => r.horizon === 60 && r.cost_model === 'corwin_schultz' && r.decision_layer === 'candidate' && r.portfolio_basis === 'all');
  const insufficient=report.status==='insufficient_cases'?`<p class="protocol-warning">樣本數 ${report.unique_cases || 0} / ${report.required_cases || 30} 不足，尚未產出任何統計檢定。</p>`:'';
  element.innerHTML = `<div class="section-label">PRIMARY ENDPOINT / 60 交易日</div><h2>同協議研究比較</h2><p class="hint">候選決策、60 日、Corwin–Schultz、固定權重投組。${report.unique_cases || 0} 個已完成案例；後續重跑保留供稽核。</p>${insufficient}<div class="table-wrap"><table><thead><tr><th>方法</th><th>覆蓋率</th><th>條件準確率</th><th>Hold</th><th>Sharpe</th><th>總報酬</th></tr></thead><tbody>${primary.map(r => `<tr><td>${escape(r.group)}</td><td>${percentage(r.coverage)}</td><td>${percentage(r.selective_accuracy)}</td><td>${percentage(r.hold_rate)}</td><td>${number(r.sharpe)}</td><td>${percentage(r.total_return)}</td></tr>`).join('')}</tbody></table></div><p class="hint">Pilot：${escape(pilot.verdict||'—')} · ${escape((pilot.blocking_reasons||[]).join(' / ')||'無阻擋原因')}。中性帶敏感性已用既有預測重算，不重新呼叫模型。</p><div class="actions"><a href="/api/studies/${selectedProtocol}/summary.csv">下載 summary.csv</a><a href="/api/studies/${selectedProtocol}" download="statistics.json">下載 statistics.json</a></div><details><summary>Pilot、hold band 與完整性診斷</summary><pre>${escape(JSON.stringify({pilot,hold_band:band,completeness:report.completeness},null,2))}</pre></details><details><summary>統計檢定與口徑</summary><pre>${escape(JSON.stringify({comparisons:report.comparisons,conventions:report.conventions},null,2))}</pre></details>`;
}
function panelData(snapshot,name) { return snapshot.panels?.[name]?.status==='ready' ? snapshot.panels[name].data : null; }
function unavailable(snapshot,name) { return snapshot.panels?.[name]?.message || '目前方案或來源未回傳資料'; }
function renderLiveSnapshot(snapshot) {
  const quote=panelData(snapshot,'quote'), market=panelData(snapshot,'market_status');
  const earnings=panelData(snapshot,'earnings_calendar')?.earningsCalendar||[];
  const recommendationData=panelData(snapshot,'recommendation_trends');const recommendations=Array.isArray(recommendationData)?recommendationData:[];
  const target=panelData(snapshot,'price_target'), holidays=panelData(snapshot,'market_holidays')?.data||[];
  const nextEarnings=[...earnings].sort((a,b)=>String(a.date).localeCompare(String(b.date)))[0];
  const latestRecommendation=[...recommendations].sort((a,b)=>String(b.period).localeCompare(String(a.period)))[0];
  $('live-badge').className=`status ${snapshot.status==='ready'?'complete':'paused'}`; $('live-badge').textContent=`${snapshot.symbol} · ${snapshot.status==='ready'?'已更新':snapshot.status==='partial'?'部分可用':'尚無可用資料'}`;
  $('live-overview').innerHTML=`<article><small>最新價</small><strong>${quote?Number(quote.current).toFixed(2):'—'}</strong><small>${quote&&quote.change_percent!=null?`${Number(quote.change_percent).toFixed(2)}%`:'Quote 無資料'}</small><small>${quote?`${escape(formatStamp(new Date(quote.timestamp*1000)))} · ${quote.stale?'過期／可能為休市最後成交':'5 分鐘內'}`:escape(unavailable(snapshot,'quote'))}</small></article><article><small>美股市場</small><strong>${market?(market.isOpen?'開市':'休市'):'—'}</strong><small>${escape(market?.session||unavailable(snapshot,'market_status'))}</small></article><article><small>下一筆財報</small><strong>${escape(nextEarnings?.date||'—')}</strong><small>${escape(nextEarnings?.hour||unavailable(snapshot,'earnings_calendar'))}</small></article><article><small>目標價均值</small><strong>${target?.targetMean?Number(target.targetMean).toFixed(2):'—'}</strong><small>${target?.numberAnalysts?`${target.numberAnalysts} 位分析師`:escape(unavailable(snapshot,'price_target'))}</small></article>`;
  const rec=latestRecommendation?`Strong buy ${latestRecommendation.strongBuy||0} · Buy ${latestRecommendation.buy||0} · Hold ${latestRecommendation.hold||0} · Sell ${(latestRecommendation.sell||0)+(latestRecommendation.strongSell||0)}`:unavailable(snapshot,'recommendation_trends');
  const holidayText=holidays.slice(0,4).map(row=>`${row.atDate} ${row.eventName}`).join('；')||unavailable(snapshot,'market_holidays');
  const panelStates=Object.entries(snapshot.panels||{}).map(([name,panel])=>`${name}: ${panel.status}${panel.message?' · '+panel.message:''}`).join('；');
  const earningText=earnings.slice(0,4).map(row=>`${row.date} ${row.hour||''} · EPS est. ${row.epsEstimate??'—'}`).join('；')||unavailable(snapshot,'earnings_calendar');
  $('live-details').innerHTML=`<p class="hint">${escape(panelStates)}</p><div class="live-grid"><article><h3>分析師評等趨勢</h3><p>${escape(rec)}</p></article><article><h3>近期交易日曆</h3><p>${escape(holidayText)}</p></article><article><h3>財報發布日曆</h3><p>${escape(earningText)}</p></article><article><h3>資料隔離</h3><p>${escape(snapshot.note)}</p></article></div>`;
}
async function refreshLive() {
  const symbol=$('live-ticker').value.trim().toUpperCase(); $('live-ticker').value=symbol;
  const snapshot=await api(`/api/live/${encodeURIComponent(symbol)}`); renderLiveSnapshot(snapshot);
}
function stopLiveStream(message='成交串流已停止') {
  if(liveSocket){liveSocket.onclose=null;liveSocket.close();liveSocket=null;}
  $('live-stream-toggle').textContent='開始成交串流';
  $('live-stream').innerHTML+=`<div class="terminal-line warn"><time>${escape(terminalStamp())}</time><b>[LIVE]</b><span>${escape(message)}</span></div>`;
}
function toggleLiveStream() {
  if(liveSocket){stopLiveStream();return;}
  const symbol=$('live-ticker').value.trim().toUpperCase(); $('live-ticker').value=symbol;
  const scheme=location.protocol==='https:'?'wss':'ws';
  liveSocket=new WebSocket(`${scheme}://${location.host}/ws/live?symbols=${encodeURIComponent(symbol)}`);
  $('live-stream').innerHTML=''; $('live-stream-toggle').textContent='停止成交串流';
  liveSocket.onmessage=event=>{let payload;try{payload=JSON.parse(event.data);}catch{payload={type:'message',data:event.data};}
    if(payload.type==='heartbeat'||payload.type==='ping')return;
    if(payload.type==='trade'&&Array.isArray(payload.data)){
      for(const trade of payload.data.slice(-20))$('live-stream').innerHTML+=`<div class="terminal-line ok"><time>${escape(terminalStamp(new Date(trade.t)))}</time><b>[TRADE]</b><span>${escape(trade.s||symbol)} · ${escape(trade.p)} × ${escape(trade.v)}</span></div>`;
    }else $('live-stream').innerHTML+=`<div class="terminal-line ${payload.type==='error'?'error':'active'}"><time>${escape(terminalStamp())}</time><b>[${escape((payload.type||'LIVE').toUpperCase())}]</b><span>${escape(payload.message||payload.status||JSON.stringify(payload))}</span></div>`;
    while($('live-stream').children.length>80)$('live-stream').firstElementChild.remove();$('live-stream').scrollTop=$('live-stream').scrollHeight;
  };
  liveSocket.onerror=()=>notify('Finnhub 成交串流無法連線；請確認金鑰與方案權限。',true);
  liveSocket.onclose=()=>{liveSocket=null;$('live-stream-toggle').textContent='開始成交串流';};
}
async function initialize() {
  const c = await api('/api/config');
  document.querySelector('.live-panel')?.classList.toggle('demo-disabled', !c.live_enabled);
  parallelWorkers = c.parallel_workers || 1;
  currentProtocolVersion = c.default_protocol?.version || '';
  const protocolTag = document.querySelector('.tag');
  if (protocolTag && currentProtocolVersion) protocolTag.textContent = `${currentProtocolVersion} 研究協議`;
  finbertReady=Boolean(c.sources?.finbert_local);
  resetAgentTerminal();
  terminalLine('SYSTEM', `Agent Shell ready · protocol ${currentProtocolVersion}`, 'ok');
  terminalLine('COORD', `等待四域資料任務 · worker=${parallelWorkers}`);
  terminalLine('SOURCE', Object.entries(c.sources).filter(([,ready])=>ready).map(([name])=>name.toUpperCase()).join(' · ') || '尚未設定外部來源', Object.values(c.sources).some(Boolean)?'ok':'warn');
  $('login').hidden = true; $('workspace').hidden = false;
  $('ticker').innerHTML = options(c.tickers); $('ticker').value = 'NVDA';
  $('download-date').innerHTML = c.dates.map(v=>`<option value="${escape(v)}">${escape(v)} · 季末研究日</option>`).join('');
  $('analysis-date').innerHTML = c.dates.map(v=>`<option value="${escape(v)}">${escape(v)} · 季末研究日</option>`).join('');
  $('download-date').value = '2024-12-31'; $('analysis-date').value = '2024-12-31';
  const sourceLabels={sec:'SEC',alfred:'FRED／ALFRED',alpha_vantage:'Alpha Vantage',fnspid:'FNSPID',finbert_local:'本機 FinBERT',finnhub:'Finnhub 即時'};
  $('source-state').textContent=Object.entries(c.sources).map(([key,value])=>`${sourceLabels[key]||key}：${value?'已設定':'未設定'}`).join(' · ');
  $('download-finbert').checked=finbertReady;
  $('live-source-state').textContent=c.sources.finnhub?'Finnhub 已由伺服器安全設定；Web 與終端共用同一資料代理。':'尚未設定 FINNHUB_API_KEY。可在上方設定表單或終端 settings 指令填入，立即套用。';
  const cloudLabels={openrouter:'OpenRouter',openai:'OpenAI',gemini:'Gemini'};
  const readyCloud=Object.entries(c.cloud_models||{}).filter(([,value])=>value).map(([key])=>cloudLabels[key]||key);
  $('cloud-model-state').textContent=readyCloud.length?`可用雲端憑證：${readyCloud.join('、')}。輸入 LiteLLM 模型名稱即可切換。`:'尚未設定常用雲端模型金鑰；可先使用 Ollama，或在上方設定表單填入金鑰。';
  await refreshSettings(); await refreshDatasets(); await refreshReadiness(); await refreshJobs();
  const m = await api('/api/models');
  const formal=(m.details||[]).filter(item=>Number.parseFloat(item.parameter_size)>=14);
  $('model-state').textContent = m.ready ? (formal.length
    ? `Ollama 已連線 · ${m.models.length} 個本機模型 · ${formal.length} 個符合 14B 研究門檻`
    : `Ollama 已連線 · ${m.models.length} 個本機模型；尚未偵測到 14B 以上模型，14B 以下僅可作冒煙測試`) : m.message;
  const models=[...new Set([c.model,...m.models])]; $('model').innerHTML=modelOptions(models,m.details); $('model').value=c.model;
}
$('login-form').addEventListener('submit', e => { e.preventDefault(); task(e.submitter, async()=>{await api('/api/login',{key:$('access-key').value}); $('access-key').value=''; await initialize();}); });
$('download-form').addEventListener('submit', e => { e.preventDefault(); task(e.submitter, async()=>{const ticker=$('ticker').value,analysisDate=$('download-date').value,refresh=$('refresh-data').checked,useFinbert=$('download-finbert').checked;resetAgentTerminal();terminalLine('YOU',`collect --ticker ${ticker} --as-of ${analysisDate} --domains all${refresh?' --refresh':''}${useFinbert?' --finbert':''}`,'command');terminalLine('COORD',refresh?`強制建立 ${analysisDate} 新快照，派發 4 個資料 Agent`:`先搜尋 ${ticker}／${analysisDate} 可重用的四域完整快照`);notify('資料 Agent 正在檢查快照與來源…');renderCollectionAgents(null,'running');let r;try{r=await api('/api/datasets/download',{ticker,analysis_date:analysisDate,refresh,use_finbert:useFinbert});}catch(error){terminalLine('ERROR',error.message,'error');renderCollectionAgents(datasetRows.find(d=>d.id===$('dataset').value)||null);throw error;}if(r.reused){terminalLine('CACHE',`HIT dataset v${r.version} · ${r.id.slice(0,12)}… · 未呼叫外部 API`,'ok');}else{terminalLine('COORD','已完成四域來源派工：Yahoo／SEC／Alpha+FNSPID／ALFRED');}const codes={technical:'TECH',fundamental:'FUND',sentiment:'SENT',macro:'MACRO'};for(const [domain,item] of Object.entries(r.agents))terminalLine(codes[domain],`${item.status.toUpperCase()} · ${item.records} records · ${item.message}`,item.status==='complete'?'ok':'warn');for(const limitation of r.limitations)terminalLine('AUDIT',limitation,'warn');if(!r.reused)terminalLine('STORE',`SAVED dataset ${r.id.slice(0,12)}… · immutable snapshot`,'ok');await refreshDatasets();await refreshReadiness();$('dataset').value=r.id;$('analysis-date').value=r.analysis_date;renderDatasetDetail();renderCollectionAgents(datasetRows.find(d=>d.id===r.id));notify(r.reused?'已重用符合條件的既有資料快照；未重新呼叫來源 API。':'資料 Agent 已完成本輪工作，資料集已保存。\n'+r.limitations.join('\n'));}); });
$('source-check-button').addEventListener('click', e => task(e.currentTarget,async()=>{const result=await api('/api/sources/check',{ticker:$('ticker').value,analysis_date:$('download-date').value});const label={alpha_vantage:'Alpha Vantage',fnspid:'FNSPID'};notify(Object.entries(result).map(([key,value])=>`${label[key]}：${value.message}（${value.records} 筆）`).join('\n'));}));
$('import-file').addEventListener('change', e => task(null,async()=>{const f=e.target.files[0];if(!f)return;const useFinbert=$('use-finbert').checked;const r=await api(`/api/datasets/import?use_finbert=${useFinbert}`,JSON.parse(await f.text()));await refreshDatasets();await refreshReadiness();$('dataset').value=r.id;renderDatasetDetail();renderCollectionAgents(datasetRows.find(d=>d.id===r.id));notify(r.finbert_applied?'資料集已驗證，新聞標題已由 FinBERT 分類並保存。':'資料集已驗證並保存。');}));
async function scoreSelectedDataset(id) {
  scoring=true;renderDatasetDetail();
  try {
    await api(`/api/datasets/${encodeURIComponent(id)}/finbert/start`,{});
    while(true){
      const state=await api(`/api/datasets/${encodeURIComponent(id)}/finbert`);
      $('finbert-progress').textContent=`${state.completed||0}/${state.total||'?'} 則 · ${state.message||state.stage}`;
      if(state.stage==='complete' && state.result){await refreshDatasets();await refreshReadiness();$('dataset').value=state.result.id;renderDatasetDetail(true);notify(`FinBERT 已建立新版本，${state.result.items} 則標題全部完成。`);break;}
      if(['failed','idle'].includes(state.stage))throw new Error(state.message||'FinBERT 未完成；可重試');
      await new Promise(resolve=>setTimeout(resolve,1500));
    }
  } finally {scoring=false;renderDatasetDetail();}
}
$('score-finbert-button').addEventListener('click',e=>task(e.currentTarget,()=>scoreSelectedDataset($('dataset').value)));
$('news-view').addEventListener('click',e=>task(e.currentTarget,async()=>{
  const id=$('dataset').value;if(!id)throw new Error('請先選擇資料集');
  const dataset=await api(`/api/datasets/${encodeURIComponent(id)}`);
  $('news-scores').innerHTML=dataset.evidence.filter(row=>row.domain==='sentiment').map(row=>`<article><b>${escape(row.headline||row.claim)}</b><p>${escape(row.available_at)} · ${escape(row.sentiment_label||'尚未評分')} · 分數 ${number(row.sentiment_score)}</p>${row.sentiment_scores?`<small>正向 ${percentage(row.sentiment_scores.positive)} · 中性 ${percentage(row.sentiment_scores.neutral)} · 負向 ${percentage(row.sentiment_scores.negative)}</small>`:''}<p class="hint">${escape(row.sentiment_method||row.source_type||'原始證據')} · ${escape(row.source)}</p></article>`).join('')||'此版本沒有新聞證據';
}));
async function refreshSettings(){
  const settings=await api('/api/settings');
  $('settings-fields').innerHTML=settings.fields.map(field=>`<label>${escape(field.label)} · ${field.configured?'已設定':'未設定'}<input data-setting="${escape(field.name)}" type="${field.secret?'password':'text'}" autocomplete="off" placeholder="留白保留原值"></label><label class="check"><input type="checkbox" data-clear-setting="${escape(field.name)}">清除此設定</label>`).join('');
}
$('settings-form').addEventListener('submit',e=>{e.preventDefault();task(e.submitter,async()=>{
  const values={};document.querySelectorAll('[data-setting]').forEach(input=>{if(input.value.trim())values[input.dataset.setting]=input.value.trim();});
  const clear=[...document.querySelectorAll('[data-clear-setting]:checked')].map(input=>input.dataset.clearSetting);
  await api('/api/settings',{values,clear});await refreshSettings();notify('設定已儲存在伺服器並立即生效。');
  const c=await api('/api/config');$('live-source-state').textContent=c.sources.finnhub?'Finnhub 已設定，可進行真實連線檢查':'尚未設定 Finnhub 金鑰';
});});
$('batch-file').addEventListener('change', e => task(null,async()=>{const f=e.target.files[0];if(!f)return;const ids=await api('/api/batches',JSON.parse(await f.text()));notify(`已加入 ${ids.length} 個研究案例。`);await refreshJobs();}));
$('job-form').addEventListener('submit', e => {e.preventDefault();if(submitting)return;if(!$('dataset').value){notify('請先選擇一筆資料集，才能開始研究實驗。',true);syncExperimentGuard();return;}submitting=true;task(e.submitter,async()=>{try{const model=$('cloud-model').value.trim()||$('model').value;const j=await api('/api/jobs',{dataset_id:$('dataset').value,analysis_date:$('analysis-date').value,model,study:$('study').value,voting_samples:Number($('voting').value),missing_data_policy:$('missing-policy').value,anonymize_ticker:$('anonymize').checked,allow_small_model:$('allow-small-model').checked,allow_low_quality_sentiment:$('allow-low-quality-sentiment').checked});selectedJob=j.id;notify(`研究已加入背景佇列，模型為 ${model}。候選決策、風控決策與品質覆寫會一起鎖定於協議。`);await refreshJobs();}finally{submitting=false;}});});
document.addEventListener('click', e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.open)task(b,()=>showJob(b.dataset.open));if(b.dataset.control)task(b,async()=>{if(b.dataset.control==='cancel'&&!window.confirm('取消此實驗？已完成紀錄會保留，取消後無法續跑。'))return;await api(`/api/jobs/${selectedJob}/${b.dataset.control}`,{});await refreshJobs();});if(b.dataset.clone)task(b,async()=>{const j=await api(`/api/jobs/${b.dataset.clone}/clone`,{});selectedJob=j.id;await refreshJobs();});if(b.dataset.statistics)task(b,showStatistics);});
$('live-refresh').addEventListener('click', e=>task(e.currentTarget,refreshLive));
$('live-stream-toggle').addEventListener('click', toggleLiveStream);
$('refresh').addEventListener('click', e=>task(e.currentTarget,async()=>{await refreshDatasets();await refreshReadiness();await refreshJobs();}));
document.addEventListener('visibilitychange',()=>{
  if(document.hidden){if(pollTimer)clearTimeout(pollTimer);pollTimer=null;return;}
  task(null,refreshJobs);
});
$('dataset').addEventListener('change', ()=>{renderDatasetDetail(true);renderCollectionAgents(datasetRows.find(d=>d.id===$('dataset').value)||null);syncExperimentGuard();});
$('analysis-date').addEventListener('change',syncExperimentGuard);
$('allow-low-quality-sentiment').addEventListener('change',syncExperimentGuard);
task(null,initialize);

