"""Point-in-time coverage and outcome availability are separate properties."""
import math
import re
from statistics import median

from .protocol import COMPANY_NAMES, TICKERS, QUARTER_DATES


def _mentions_target(item, ticker):
    text = " ".join(str(item.get(key, "")) for key in ("headline", "claim"))
    if re.search(r"(?<![A-Za-z0-9])" + re.escape(ticker) + r"(?![A-Za-z0-9])", text, re.I):
        return True
    lowered = text.casefold()
    return any(name.casefold() in lowered for name in COMPANY_NAMES.get(ticker, ()))


def _sentiment_quality(data, day):
    items = [item for item in data.get("evidence", []) if item.get("domain") == "sentiment"
             and item.get("available_at", "") < day]
    mentions = sum(_mentions_target(item, data.get("ticker", "")) for item in items)
    relevance = []
    for item in items:
        try:
            value = float(item["relevance_score"])
        except (KeyError, TypeError, ValueError):
            continue
        if math.isfinite(value):
            relevance.append(value)
    rate = mentions / len(items) if items else 0.
    return {"ticker_mention_rate": rate, "median_relevance": median(relevance) if relevance else None,
            "passes_quality_gate": bool(items) and rate >= .5}


def coverage(data, analysis_date=None):
    day = analysis_date or data.get("requested_analysis_date")
    if not day:
        return {"research_ready": False, "reason": "missing_analysis_date", "domains": {}, "backtest_ready": False}
    past = [row for row in data["prices"] if row["date"] < day]
    future = [row for row in data["prices"] if row["date"] > day]
    counts = {domain: sum(item["domain"] == domain and item["available_at"] < day
                         and item.get("vintage_date", item["available_at"]) < day for item in data["evidence"])
              for domain in ("fundamental", "sentiment", "macro")}
    counts["technical"] = len(past)
    ready = len(past) >= 61 and all(counts[name] for name in ("fundamental", "sentiment", "macro"))
    sentiment_quality = _sentiment_quality(data, day)
    return {"research_ready": bool(ready), "domains": counts, "analysis_date": day,
            "historical": data["kind"] == "historical", "future_sessions": len(future),
            "backtest_ready": len(future) >= 61, "horizons": {str(n): len(future) >= n + 1 for n in (30, 60, 90)},
            "sentiment_quality": sentiment_quality,
            "reason": "ready" if ready else "insufficient_pre_cutoff_evidence"}


def study_readiness(rows):
    by_case = {}
    for row in rows:
        key = row.get("ticker"), row.get("requested_analysis_date")
        if row.get("kind") != "historical" or key[0] not in TICKERS or key[1] not in QUARTER_DATES:
            continue
        c = row["coverage"]
        rank = (c["research_ready"], c["backtest_ready"], sum(bool(n) for n in c["domains"].values()))
        previous = by_case.get(key)
        # Rows arrive newest first; prefer complete older snapshots to incomplete new ones.
        if previous is None or rank > previous["rank"]:
            by_case[key] = {**c, "rank": rank, "status": "complete" if c["research_ready"] else "partial",
                            "dataset_id": row["id"], "version": row["version"], "ticker": key[0]}
    tickers = []
    for ticker in TICKERS:
        complete = [day for day in QUARTER_DATES if by_case.get((ticker, day), {}).get("status") == "complete"]
        partial = [day for day in QUARTER_DATES if by_case.get((ticker, day), {}).get("status") == "partial"]
        tickers.append({"ticker": ticker, "complete": len(complete), "partial": len(partial),
                        "missing": len(QUARTER_DATES) - len(complete) - len(partial),
                        "complete_dates": complete, "partial_dates": partial})
    complete = sum(row["research_ready"] for row in by_case.values())
    target = len(TICKERS) * len(QUARTER_DATES)
    return {"universe": list(TICKERS), "dates": list(QUARTER_DATES), "target_cases": target,
            "complete_cases": complete, "partial_cases": len(by_case) - complete, "missing_cases": target - len(by_case),
            "backtest_ready_cases": sum(row["backtest_ready"] and row["research_ready"] for row in by_case.values()),
            "cases": [{k: v for k, v in row.items() if k != "rank"} for row in by_case.values()], "tickers": tickers,
            "note": "完整度只計算歷史資料的分析日前證據；60 日回測行情另計。ASTS 可用於即時查詢。"}
