# 本機回測 Demo

這份流程只啟用歷史回測。Finnhub 即時面板預設關閉，不會連線或執行下單。

## 啟動

在專案根目錄執行：

```powershell
.\research.ps1 doctor
.\research.ps1 start
```

開啟 <http://127.0.0.1:8000/>。服務健康檢查應顯示 `v3-0909.7`，頁面標籤會顯示相同的研究協議版本。

## 先確認資料集

```powershell
.\research.ps1 readiness
.\research.ps1 datasets
```

`datasets` 會逐筆列出完整 `dataset_id`、股票、版本、研究分析日、行情筆數與證據筆數。版本 `vN` 是同股票／資料類型的建立順序；真正用來鎖定輸入的是完整 ID。建立 FinBERT 新版本後，請重新執行這個指令，不要只依賴版本號。

目前已驗收的兩筆資料集如下；若重新匯入資料，仍以 `datasets` 顯示的 ID 為準：

| 案例 | 研究日 | 完整資料集 ID |
| --- | --- | --- |
| AAPL | 2023-09-30 | `c9101a60a490016391ab8dcf255fd9a5a3615f193d7b9d51ab50bf098709f732` |
| NVDA | 2024-12-31 | `4c9f23bc5668a28a060fd478c654cba4f71536ccf8b3c40dad07e7b28a25fb10` |

每筆驗收資料都有 4 個研究域、至少 61 個分析日前交易日，以及 30／60／90 日後續行情；新聞標題已保存 FinBERT 的正向、中性、負向機率與正向減負向分數。

## Web 回測

1. 在「資料」選擇股票與季末研究日。若已有完整快照，直接選下拉選單中的資料集；不必重新下載。
2. 確認資料集明細中的研究分析日與版本。行情終點只是未來回測資料，不能改成分析日。
3. 在「實驗」選同一筆資料集，選 `ollama/qwen3:14b` 或其他 14B 以上模型、B 組 7 次、以及「實驗對照 · 保留模型決策」。4B 只可勾選明確的冒煙測試覆寫，不能當研究比較結果。
4. 按「開始研究實驗」。畫面會依序顯示四域研究摘要、A/B/C/D 波次、Gatekeeper 與 30／60／90 日回測。
5. 本機 Ollama 預設只有一個 CPU runner，決策請求會逐一排程；頁面顯示真實持久化檢查點。關閉瀏覽器或重啟服務後，按「繼續執行」即可從最後檢查點續跑。
6. 完成後按「下載研究產物 ZIP」。ZIP 包含協議、資料版本、來源登錄表、提示雜湊、逐步論證、決策與逐日回測，以及 `manifest.json`。manifest 會列出每個研究產物的 SHA-256 與大小，可用來確認傳輸或保存後沒有被改動。

## 終端等價操作

```powershell
# 列出可用模型與資料來源狀態
.\research.ps1 models
.\research.ps1 sources AAPL 2023-09-30

# 用完整 ID 建立同一筆回測
.\research.ps1 run AAPL 2023-09-30 `
  -DatasetId c9101a60a490016391ab8dcf255fd9a5a3615f193d7b9d51ab50bf098709f732 `
  -Model ollama/qwen3:14b -VotingSamples 7 -MissingDataPolicy allow_decision

# 查進度、暫停、繼續、取消與匯出
.\research.ps1 jobs
.\research.ps1 job -JobId <JOB_ID>
.\research.ps1 pause -JobId <JOB_ID>
.\research.ps1 resume -JobId <JOB_ID>
.\research.ps1 export -JobId <JOB_ID> -File .\demo-output.zip
.\research.ps1 verify-export -File .\demo-output.zip
.\research.ps1 backup -File .\demo-backup.zip
.\research.ps1 verify-export -File .\demo-backup.zip
```

Web 與終端共用同一個服務、SQLite 資料庫、資料集 ID、模型設定與工作佇列；在一邊建立的工作，另一邊重新整理即可看到。終端會完整列出 ID，避免 PowerShell 表格寬度截斷。

網頁在有執行中工作時每 3 秒更新；閒置時改為每 30 秒檢查一次，切到背景分頁會暫停更新。回到頁面時會立刻同步，因此終端新建的工作仍會出現在網頁中。

## 如何解讀狀態

- `四域完整` 表示分析日當時的 technical、fundamental、sentiment、macro 證據都存在。
- `60 日行情也齊全` 表示後續行情足以計算主要回測；這和四域證據完整分開計算。
- 缺少研究域時，`allow_decision` 會保留模型候選決策並標記缺口；`force_no_trade` 才會由 Gatekeeper 強制 NoTrade。
- 模型逾時、網路中斷或輸出格式錯誤會讓工作停在可重試狀態，不能當成 NoTrade 或成功。
- 舊協議工作只能檢視；使用「複製至新版」建立新工作，原始設定與結果會保留。

## 目前 demo 與正式研究的界線

本機資料庫的既有 AAPL 2023-09-30 與 NVDA 2024-12-31 `v3-0907.3` 工作只保留作流程基準；數字、引用與決策引用重試修正後，請以「複製至新版」或重新建立的 `v3-0908.2` 工作驗收。少量案例只能驗收系統，不能當成 180 案例論文結論。

研究資料、設定與本次兩筆完成報告備份位於 `.\_stance_shift_backups\20260908-1745-demo`。不要執行 `docker compose down -v`，否則會刪除具名資料卷。即時 Finnhub、ASTS 查詢與券商下單仍是後續階段；本 demo 只做觀察、研究與回測。
