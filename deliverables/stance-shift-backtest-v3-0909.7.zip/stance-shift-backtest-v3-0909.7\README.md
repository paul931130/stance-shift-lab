# Stance Shift Research v3

可實際執行的多代理人立場交換回測研究台。正式入口是 Docker 化的 FastAPI 服務：四個資料 Agent 建立具時間邊界的不可變資料快照，A/B/C/D 使用同一份快照比較單次判斷、獨立投票、固定立場辯論與立場交換辯論。

## 快速開始

需求：Windows 10/11、Docker Desktop，以及 Ollama 或一組雲端模型金鑰。

```powershell
.\research.ps1 setup
.\research.ps1 start
```

開啟 <http://127.0.0.1:8000/>。也可直接雙擊 `start-research.cmd`。

網頁負責互動式研究操作與結果檢視；終端負責安裝設定、啟停、檢查、日誌與批次工作：

```powershell
.\research.ps1 doctor
.\research.ps1 collect NVDA 2024-12-31
.\research.ps1 run NVDA 2024-12-31
.\research.ps1 jobs
.\research.ps1 logs
```

研究執行預設使用 `ollama/qwen3:14b`。若只想用較小模型驗證流程，需明確加上 `-Model ollama/qwen3:8b -AllowSmallModel`；這類結果只算冒煙測試，不納入正式研究比較。

執行 `.\research.ps1 help` 可查看完整命令。`start` 會先檢查 Docker Linux engine，未啟動時嘗試開啟 Docker Desktop 並給出可操作的錯誤訊息。`collect` 會重用同股票、同分析日且四域完整的既有快照；加上 `-Refresh` 才會重新呼叫資料來源。

## 回測資料

| 研究域 | 正式來源 | 建立快照時的處理 |
| --- | --- | --- |
| 技術面 | Yahoo Finance adjusted OHLC | 下載分析日前行情與 30/60/90 日回測需要的未來行情 |
| 基本面 | SEC XBRL | 依 filing date 保存分析日前可得的財報證據 |
| 情緒面 | Alpha Vantage、FNSPID、可選本機 FinBERT | 使用分析日前 90 天的標題／摘要；Alpha Vantage 以目標 ticker 相關性排序並過濾，FNSPID 本機檔只保存必要欄位；FinBERT 對標題離線評分 |
| 總經面 | FRED/ALFRED | 依 vintage date 保存當時可取得的總經資料 |

四域資料在「建立資料集」時取得並寫入持久化 SQLite；執行 A/B/C/D 模型實驗時只讀選定的 dataset ID，不會再次呼叫市場資料 API。重跑模型時應重用同一資料集，才能維持公平比較。建立新實驗前，系統會檢查新聞標題中目標公司提及率；未達 50% 時必須重新採集或明確標記為資料品質敏感性覆寫。

## 憑證與資料安全

`.\research.ps1 setup` 會隱藏秘密輸入並寫入 Git 忽略的 `.env.research`。網頁只顯示來源是否就緒，不把 API key 寫入瀏覽器儲存空間。公開部署時，憑證屬於伺服器營運者；若未來改成多使用者服務，必須另做使用者身分、加密憑證庫、額度與隔離，不能共用目前的單一研究室設定。

以下內容不會進入 Git 或 Docker 映像：

- `.env.research` 與所有 API key
- `research-inputs/*.csv`、原始 FNSPID 檔
- SQLite 研究資料、工作輸出與本機模型

資料授權仍由部署者負責。不要把 Yahoo、FNSPID 或其他來源的原始資料直接提交到公開儲存庫。

## 專案結構

- `research_service/`：正式 FastAPI 後端、研究流程與網頁工作台
- `research-inputs/`：本機唯讀資料輸入；大型檔案由 Git 忽略
- `scripts/`：FNSPID 整理、CLI 與驗證工具
- `docs/`：研究口徑、操作、部署與審查文件
- `compose.research.yaml`、`Dockerfile.research`：正式執行封裝
- `app/`、`lib/`、Node 設定：舊版 Sites/Next 示範台，正式研究服務不會載入

更完整的整理原則見 [專案結構](docs/project-layout.md)，正式研究與公開發布前的完整排序清單見 [最終審查](docs/final-review-2026-09-07.md)。

第一次只想驗證回測流程，可照 [本機回測 Demo](docs/demo-backtest.md) 操作。這份流程會固定在歷史資料模式，並說明如何辨認完整資料集 ID、暫停續跑與匯出研究產物。

## 驗證與部署

```powershell
docker compose -f compose.research.yaml build research
docker compose -f compose.research.yaml run --rm --no-deps research python -m unittest discover -s research_service/tests -p test_*.py
node --check research_service\static\app.js
```

公開伺服器需使用 HTTPS 反向代理、至少 32 字元的研究室存取金鑰與持久化備份。GitHub Pages、純 Cloudflare Workers 以及靜態網站無法執行此 Python/Ollama 後端。詳見 [部署指南](docs/deploy-v3.md) 與 [GitHub 發布檢查表](docs/github-release-checklist.md)。

本系統只用於研究與教育，不執行交易。單筆試跑與合成測試不能當成投資績效結論。
