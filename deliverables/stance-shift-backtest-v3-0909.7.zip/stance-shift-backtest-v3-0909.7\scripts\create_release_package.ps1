[CmdletBinding()]
param(
    [string]$Version = 'v3-0909.7',
    [string]$OutputDirectory = 'release'
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$releaseName = "stance-shift-backtest-$Version"
if ([System.IO.Path]::IsPathRooted($OutputDirectory)) {
    $outputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
}
else {
    $outputDirectory = [System.IO.Path]::GetFullPath((Join-Path $root $OutputDirectory))
}
$archivePath = Join-Path $outputDirectory "$releaseName.zip"

if (Test-Path -LiteralPath $archivePath) {
    throw "Release archive already exists: $archivePath"
}

$temporaryRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("stance-release-" + [guid]::NewGuid().ToString('N'))
$packageRoot = Join-Path $temporaryRoot $releaseName
New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null
New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null

$files = @(
    '.dockerignore', '.gitignore', 'Dockerfile.research', 'compose.research.yaml',
    'README.md', 'research.cmd', 'research.ps1', 'start-research.cmd', 'start-local.cmd',
    'research.env.example', 'research-inputs\README.md', 'deploy\Caddyfile.example',
    'scripts\researchctl.ps1', 'scripts\prepare_fnspid_news.py', 'scripts\create_release_package.ps1'
)
$directories = @('research_service', 'docs')

function Copy-ReleaseFile([string]$relativePath) {
    $source = Join-Path $root $relativePath
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw "Required release file is missing: $relativePath"
    }
    $destination = Join-Path $packageRoot $relativePath
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination -Force
}

function Copy-ReleaseTree([string]$relativePath) {
    $source = Join-Path $root $relativePath
    if (-not (Test-Path -LiteralPath $source -PathType Container)) {
        throw "Required release directory is missing: $relativePath"
    }
    Get-ChildItem -LiteralPath $source -Recurse -File | Where-Object {
        $_.FullName -notmatch '\\(__pycache__|node_modules|research-data|\.git)\\' -and
        $_.Extension -notin @('.pyc', '.pyo')
    } | ForEach-Object {
        $relative = $_.FullName.Substring($root.Length).TrimStart('\', '/')
        $destination = Join-Path $packageRoot $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
    }
}

$files | ForEach-Object { Copy-ReleaseFile $_ }
$directories | ForEach-Object { Copy-ReleaseTree $_ }

$manifest = [ordered]@{
    schema = 'stance-shift-release/v1'
    version = $Version
    created_at_utc = (Get-Date).ToUniversalTime().ToString('o')
    purpose = 'Local historical backtest demo; no broker order execution.'
    excluded = @('.env.research', 'API keys', 'SQLite research database', 'raw FNSPID news CSV', 'local Ollama models')
    files = @(Get-ChildItem -LiteralPath $packageRoot -Recurse -File | ForEach-Object {
        $_.FullName.Substring($packageRoot.Length).TrimStart('\', '/').Replace('\', '/')
    } | Sort-Object)
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $packageRoot 'PACKAGE_MANIFEST.json') -Encoding utf8

Compress-Archive -LiteralPath $packageRoot -DestinationPath $archivePath -CompressionLevel Optimal
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    $forbidden = $archive.Entries | ForEach-Object { $_.FullName.Replace('\', '/') } | Where-Object {
        $_ -match '(^|/)\.env(\.|$)|(^|/)research-data/|(^|/)Stock_news\.csv$|(^|/)__pycache__/'
    }
    if ($forbidden) {
        throw "Release archive contains excluded material: $($forbidden -join ', ')"
    }
}
finally {
    $archive.Dispose()
}

[PSCustomObject]@{
    archive = $archivePath
    bytes = (Get-Item -LiteralPath $archivePath).Length
    sha256 = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash
} | ConvertTo-Json -Compress
